SHRI AI — Android Starter (Version 1)

क्या काम करता है:
- Black & Gold बेसिक ऐप स्क्रीन
- टेक्स्ट लिखकर सवाल भेजना
- Android Speech Recognition से हिंदी बोलकर इनपुट
- Android Text-to-Speech से जवाब सुनना
- AI backend जोड़ने के लिए HTTPS endpoint placeholder

कैसे खोलें:
1. Android Studio इंस्टॉल करें।
2. इस ZIP को extract करें।
3. Android Studio में Open चुनकर SHRI-AI फ़ोल्डर खोलें।
4. Gradle sync पूरा होने दें।
5. OPPO Reno 7 Pro को USB से जोड़ें, Developer options में USB debugging चालू करें।
6. Run दबाएँ और Microphone permission Allow करें।

असली AI जोड़ना:
- MainActivity.kt में aiEndpoint को अपने HTTPS backend के URL से बदलें।
- Backend POST JSON {"message":"..."} ले और JSON {"reply":"..."} लौटाए।
- OpenAI/API secret key केवल backend पर रखें; Android APK में कभी न डालें।
- अभी endpoint placeholder है, इसलिए ऐप demo जवाब देता है।

ज़रूरी सीमाएँ:
- यह starter app है, पूरा तैयार commercial assistant नहीं।
- "Hey SHRI" हमेशा सुनना और स्क्रीन बंद होने पर wake-word चलाना इसमें अभी शामिल नहीं है।
  Android पर इसके लिए अलग on-device wake-word engine, foreground microphone service,
  स्पष्ट user permission और battery/background व्यवहार का परीक्षण चाहिए।
- Speech recognition फोन की उपलब्ध भाषा/Google speech service पर निर्भर कर सकती है।
