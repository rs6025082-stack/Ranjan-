package com.shri.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var statusText: TextView
    private lateinit var userText: TextView
    private lateinit var replyText: TextView
    private lateinit var messageInput: EditText
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val executor = Executors.newSingleThreadExecutor()

    // अपनी HTTPS backend URL यहाँ डालें। API key कभी Android app में न रखें।
    private val aiEndpoint = "https://YOUR-SERVER.example/api/chat"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        userText = findViewById(R.id.userText)
        replyText = findViewById(R.id.replyText)
        messageInput = findViewById(R.id.messageInput)
        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.sendButton).setOnClickListener {
            val message = messageInput.text.toString().trim()
            if (message.isNotEmpty()) handleMessage(message)
        }
        findViewById<Button>(R.id.micButton).setOnClickListener { startListening() }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            tts.stop()
            speechRecognizer?.cancel()
            statusText.text = "आवाज़ रोक दी गई।"
        }
        requestMicPermission()
    }

    private fun requestMicPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "इस फोन पर Speech Recognition उपलब्ध नहीं है।"
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            requestMicPermission()
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { statusText.text = "सुन रहा हूँ..." }
            override fun onBeginningOfSpeech() { statusText.text = "बोलिए..." }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { statusText.text = "समझ रहा हूँ..." }
            override fun onError(error: Int) { statusText.text = "आवाज़ समझ नहीं आई। फिर कोशिश करें।" }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) handleMessage(spoken)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "SHRI से बात करें")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun handleMessage(message: String) {
        userText.text = "आप: $message"
        statusText.text = "SHRI जवाब तैयार कर रहा है..."
        messageInput.setText("")
        executor.execute {
            val answer = askBackend(message)
            runOnUiThread {
                replyText.text = "SHRI: $answer"
                statusText.text = "तैयार हूँ।"
                if (::tts.isInitialized) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "shri_reply")
            }
        }
    }

    private fun askBackend(message: String): String {
        if (aiEndpoint.contains("YOUR-SERVER")) {
            return "आपने कहा: $message। AI जवाब चालू करने के लिए ऐप में अपना सुरक्षित HTTPS backend जोड़ना होगा।"
        }
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(aiEndpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 20000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val body = JSONObject().put("message", message).toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            JSONObject(response).optString("reply", "माफ़ कीजिए, जवाब नहीं मिला।")
        } catch (e: Exception) {
            "कनेक्शन में समस्या है। इंटरनेट और AI सर्वर जाँचें।"
        } finally {
            connection?.disconnect()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale.US
            }
            tts.setSpeechRate(0.96f)
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdown()
        super.onDestroy()
    }
}
